GAMEVERSE Android project (GitHub Actions build)

This is Android source code, NOT an APK.
Upload the CONTENTS of this folder to the root of your GitHub repository.
Make sure hidden .github folder is included.
Then open GitHub > Actions > Build GAMEVERSE APK > Run workflow.
When successful, download the GAMEVERSE-debug-APK artifact.

The app wraps the included offline HTML demo in an Android WebView.
The demo's AI assistant is not connected to a live AI model; online accounts,
server database, payments, and multiplayer services are not included.
